# cucumber
Basic cucumber tests structure with examples, of data tables, examples and background. Small Jenkins pipeline inside.

Starting with cucumber? Use this repository to see how a complete maven project with cucumber looks like.

It contains:
- example structure for the project (pom file)

- basic cucumber test types:

- basic test

- datatables tests

- scenario outline

- background example

Just run

```
mvn test
```
